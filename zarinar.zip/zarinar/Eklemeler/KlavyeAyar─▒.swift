//
//  KlavyeAyarı.swift
//  zarinar
//
//  Created by Adem Tarhan on 2.11.2020.
//

import Foundation
import UIKit

extension UIView{
    
    func KlavyeAyarla(){
        NotificationCenter.default.addObserver(self, selector: #selector(klavyeKonumuAyarla(_ :)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }
    
    @objc private func klavyeKonumuAyarla(_ notification : NSNotification){
        
        let sure = notification.userInfo![UIResponder.keyboardAnimationDurationUserInfoKey] as! Double
        let egri = notification.userInfo![UIResponder.keyboardAnimationCurveUserInfoKey] as! UInt
        let baslangicFrame = ( notification.userInfo![UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        let bitisFrame = (notification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let farkY = bitisFrame.origin.y - baslangicFrame.origin.y
        UIView.animateKeyframes(withDuration: sure, delay: 0.0, options: UIView.KeyframeAnimationOptions.init(rawValue: egri), animations: {
            self.frame.origin.y += farkY
        }, completion: nil)
    }
    
}
