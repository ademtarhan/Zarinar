//
//  Sabitler.swift
//  zarinar
//
//  Created by Adem Tarhan on 24.10.2020.
//

import Foundation

let Fikirler_REF = "Fikirler"
let KATEGORI = "Kategori"
let Begeni_Sayisi = "BegeniSayisi"
let Yorum_Sayisi = "YorumSayisi"
let Fikir_Text = "FikirText"
let Eklenme_Tarihi = "EklenmeTarihi"
let Kullanici_Adi = "KullaniciAdi"
let KULLANICI_ID = "KullaniciId"
let PROFIL_REF = "Profil"
//let PAYLASIMLAR_REF = "Paylasimlar"
let PAYLASIMLAR_REF = "Paylasimlar"
let PROFIL_YORUM_REF = "yorumlar"
let HAKKINDA = "Hakkinda"
let PROFIL_RESMI = "ProfilResmi"
let KULLANICILAR_REF = "Kullanicilar"
let KULLANICI_ADI = "KullaniciAdi"
let KULLANICI_OLUSTURMA_TARIHI = "KullaniciOlusturmaTarihi"
let PAROLA = "Parola"
let KULLANICI_EMAIL = "KullaniciEmail"
let YORUMLAR_REF = "Yorumlar"
let YORUM_TEXT = "YorumText"


let KULLANICI_REF = "Kullanici"
