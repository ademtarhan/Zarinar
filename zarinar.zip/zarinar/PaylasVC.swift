//
//  PaylasViewController.swift
//  zarinar
//
//  Created by Adem Tarhan on 20.10.2020.
//

import Foundation
import UIKit

class Paylas : UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
