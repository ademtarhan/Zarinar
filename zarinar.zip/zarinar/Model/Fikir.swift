//
//  Fikir.swift
//  zarinar
//
//  Created by Adem Tarhan on 24.10.2020.
//

import Foundation
import Firebase

class Fikir {
    
    private(set) var KullaniciAdi : String!
    private(set) var EklemeTarihi : Date!
    private(set) var BegeniSayisi : Int!
    private(set) var YorumSayisi : Int!
    private(set) var FikirText : String!
    private(set) var DokumanID : String!
    private(set) var KullaniciID : String!
    
    init(KullaniciAdi : String, EklemeTarihi : Date, BegeniSayisi : Int, YorumSayisi : Int, FikirText : String, DokumanID : String, KullaniciID : String) {
        self.KullaniciAdi = KullaniciAdi
        self.EklemeTarihi = EklemeTarihi
        self.BegeniSayisi = BegeniSayisi
        self.YorumSayisi = YorumSayisi
        self.FikirText = FikirText
        self.DokumanID = DokumanID
        self.KullaniciID = KullaniciID
    }
    /*
    class func FikirleriGetir(snapshot : QuerySnapshot?) -> [Fikir]{
        var fikirler = [Fikir]()
        guard let snap = snapshot else{return fikirler}
        
        for document in snap.documents{
            let data = document.data()
            let kullaniciAdi = data[KULLANICI_ADI] as? String ?? "Misafir"
            let timesamp = data[Eklenme_Tarihi] as? Timestamp ?? Timestamp()
            let eklenmeTarihi = timesamp.dateValue()
            let fikirText = data[Fikir_Text] as? String ?? "FikirYok"
            let dokumanID = document.documentID
            let kullaniciID = data[KULLANICI_ID] as? String ?? ""
            let begeniSayisi = data[Begeni_Sayisi] as? Int ?? 0
            let yorumSayisi = data[Yorum_Sayisi] as? Int ?? 0
            
            let yeniFikir = Fikir(KullaniciAdi:kullaniciAdi, EklemeTarihi: eklenmeTarihi, BegeniSayisi: begeniSayisi, YorumSayisi: yorumSayisi, FikirText: fikirText, DokumanID: dokumanID, KullaniciID: kullaniciID)
            fikirler.append(yeniFikir)
            
        }
        return fikirler
    }
    
   */
    
}
