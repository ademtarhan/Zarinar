//
//  Paylasimlar.swift
//  zarinar
//
//  Created by Adem Tarhan on 3.11.2020.
//

import Foundation
import Firebase

class Paylasimlar {
    
    private(set) var KullaniciAdi : String!
    private(set) var Kategori : String!
    private(set) var EklenmeTarihi : Date!
    private(set) var TextFikir : String!
    private(set) var DokumanId : String!
    private(set) var KullaniciId : String!
    private(set) var BegeniSayisi : Int!
    private(set) var YorumSayisi : Int!
    
    
    init(KullaniciAdi : String ,Kategori : String , EklenmeTarihi : Date, TextFikir : String, DokumanId: String, KullaniciId : String, BegeniSayisi : Int, YorumSayisi : Int) {
        self.KullaniciAdi = KullaniciAdi
        self.Kategori = Kategori
        self.EklenmeTarihi = EklenmeTarihi
        self.TextFikir = TextFikir
        self.DokumanId = DokumanId
        self.KullaniciId = KullaniciId
        self.BegeniSayisi = BegeniSayisi
        self.YorumSayisi = YorumSayisi
    }
    
    /*
   class func GonderileriGetir(snapshot : QuerySnapshot?) -> [Paylasimlar]{
        var paylasimlar = [Paylasimlar]()
        
        guard let snap = snapshot else{return paylasimlar}
        
        for kayit in snap.documents{
            let veri = kayit.data()
            let Kategori = veri[KULLANICI_ADI] as? String ?? "Misafir"
            let timesamp = veri[Eklenme_Tarihi] as? Timestamp ?? Timestamp()
            let eklenmeTarihi = timesamp.dateValue()
            let yorumText = veri[YORUM_TEXT] as? String ?? "Yorum Yok"
            let dokumanId = kayit.documentID
            let kullaniciId = veri[KULLANICI_ID] as? String ?? ""      
            let begenisayisi = veri[Begeni_Sayisi] as? Int ?? 0
            let yorumsayisi = veri[Yorum_Sayisi] as? Int ?? 0
            
            let yeniPaylasim = Paylasimlar(KullaniciAdi: <#String#>, Kategori: Kategori, EklenmeTarihi: eklenmeTarihi, TextFikir: yorumText, DokumanId: dokumanId, KullaniciId: kullaniciId, BegeniSayisi: begenisayisi, YorumSayisi: yorumsayisi)
            paylasimlar.append(yeniPaylasim)
        }
        return paylasimlar
    }
    */
    
}

