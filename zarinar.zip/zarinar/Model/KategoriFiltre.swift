//
//  KategoriFiltre.swift
//  zarinar
//
//  Created by Adem Tarhan on 3.12.2020.
//

import Foundation


enum Kategoriler : String{
    case Eglence = "Eglence"
    case Spor = "Spor"
    case Magazin = "Magazin"
    case Teknoloji = "Teknoloji"
    case Bilim = "Bilim"
}


enum Filtreler : String {
    case Yeni = "Yeni"
    case Trend = "Trend"
}
