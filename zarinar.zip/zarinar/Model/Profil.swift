//
//  Profil.swift
//  zarinar
//
//  Created by Adem Tarhan on 2.11.2020.
//

import Foundation
import Firebase

class Profil {
    private(set) var KullaniciAdi : String!
    private(set) var Hakkinda : String!
    private(set) var ProfilResmi : UIImage!
    private(set) var DokumanID : String!
    init(KullaniciAdi : String, Hakkinda : String, ProfilResmi : UIImage, DokumanID : String) {
        self.KullaniciAdi = KullaniciAdi
        self.Hakkinda = Hakkinda
        self.ProfilResmi = ProfilResmi
        self.DokumanID = DokumanID
    }
    
    
    
    
    
    
    class func ProfilBilgileriGetir(snapshot : QuerySnapshot?) -> [Profil]{
        var profilBilgileri = [Profil]()
        guard let snap = snapshot else{return profilBilgileri}
        print("ProfilVC-Satir 24 Calisiyor")
        for bilgi in snap.documents{
            let kullaniciAdi = bilgi[KULLANICI_ADI] as? String ?? "Misafir"
            let hakkinda = bilgi[HAKKINDA] as? String ?? "Zarinar Kullaniyor"
            let profilResmi = bilgi[PROFIL_RESMI] as? UIImage ?? UIImage(named: "zarinarikon") 
            let dokumanId = bilgi.documentID
            print("ProfilVC-Satir 28 Calisiyor")
            
            let YeniProfil = Profil(KullaniciAdi: kullaniciAdi, Hakkinda: hakkinda, ProfilResmi: profilResmi!,DokumanID: dokumanId)
            profilBilgileri.append(YeniProfil)
            
        }
        
        return profilBilgileri
        
    }
   
    
}
