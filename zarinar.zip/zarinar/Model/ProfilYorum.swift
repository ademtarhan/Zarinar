//
//  ProfilYorum.swift
//  zarinar
//
//  Created by Adem Tarhan on 16.11.2020.
//


import Foundation
import Firebase

class ProfilYorum {
    
    private(set) var KullaniciAdi : String!
    private(set) var EklenmeTarihi : Date!
    private(set) var YorumText : String!
    private(set) var DokumanId : String!
    private(set) var KullaniciId : String!
    
    init(KullaniciAdi : String , EklenmeTarihi : Date, YorumText : String, DokumanId: String, KullaniciId : String) {
        self.KullaniciAdi = KullaniciAdi
        self.EklenmeTarihi = EklenmeTarihi
        self.YorumText = YorumText
        self.DokumanId = DokumanId
        self.KullaniciId = KullaniciId
    }
    
    
    class func YorumlariGetir(snapshot : QuerySnapshot?) -> [ProfilYorum]{
        var yorumlar = [ProfilYorum]()
        
        guard let snap = snapshot else{return yorumlar}
        
        for kayit in snap.documents{
            let veri = kayit.data()
            let kullaniciAdi = veri[KULLANICI_ADI] as? String ?? "Misafir"
            let timesamp = veri[Eklenme_Tarihi] as? Timestamp ?? Timestamp()
            let eklenmeTarihi = timesamp.dateValue()
            let yorumText = veri[YORUM_TEXT] as? String ?? "Yorum Yok"
            let dokumanId = kayit.documentID
            let kullaniciId = veri[KULLANICI_ID] as? String ?? ""            
            
            let yeniYorum = ProfilYorum(KullaniciAdi: kullaniciAdi, EklenmeTarihi: eklenmeTarihi, YorumText: yorumText, DokumanId: dokumanId,KullaniciId: kullaniciId)
            yorumlar.append(yeniYorum)
        }
        return yorumlar
    }
}



