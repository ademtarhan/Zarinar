//
//  YorumCell.swift
//  zarinar
//
//  Created by Adem Tarhan on 30.10.2020.
//

import UIKit
import Firebase

class YorumCell: UITableViewCell {

    @IBOutlet weak var lblYorum: UILabel!
    @IBOutlet weak var lblTarih: UILabel!
    @IBOutlet weak var lblKullaniciAdi: UILabel!
    @IBOutlet weak var imgSecenekler: UIImageView!
    var SeciliYorum : Yorum!
    var delegate : YorumDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    
    func GorunumAyarla(yorum : Yorum, delegate : YorumDelegate?){
        lblKullaniciAdi.text = yorum.KullaniciAdi
        lblYorum.text = yorum.YorumText
        let TarihFormat = DateFormatter()
        TarihFormat.dateFormat = "dd MM YYYY, hh:mm"
        let EklenmeTarihi = TarihFormat.string(from: yorum.EklenmeTarihi)
        lblTarih.text = EklenmeTarihi
        imgSecenekler.isHidden = true
        SeciliYorum = yorum
        self.delegate = delegate
        if yorum.KullaniciId == Auth.auth().currentUser?.uid{
            imgSecenekler.isHidden = false
            imgSecenekler.isUserInteractionEnabled = true
            let tap = UITapGestureRecognizer(target: self, action: #selector(imgYorumSeceneklerPressed))
            imgSecenekler.addGestureRecognizer(tap)
        }
        
    }
    @objc func imgYorumSeceneklerPressed(){
        delegate?.secenklerYorumPressed(yorum: SeciliYorum)
    }

}

protocol YorumDelegate {
    func secenklerYorumPressed(yorum: Yorum)
}



