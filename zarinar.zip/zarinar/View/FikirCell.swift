//
//  FikirCell.swift
//  zarinar
//
//  Created by Adem Tarhan on 3.11.2020.
//

import UIKit
import Firebase

class FikirCell: UITableViewCell{
    
    @IBOutlet weak var lblKullaniciAdi: UILabel!
    @IBOutlet weak var lblTarih: UILabel!
    @IBOutlet weak var lblYorumSayisi: UILabel!
    @IBOutlet weak var lblBegeniSayisi: UILabel!
    @IBOutlet weak var imgBegeni: UIImageView!
    @IBOutlet weak var lblTextFikir: UILabel!
    
    
    @IBOutlet weak var imgSecenekler: UIImageView!
    var SecilenFikir : Fikir!
    var delegate : FikirDelegate?
    
    
    
    
     
    override func awakeFromNib() {
        super.awakeFromNib()
      
        let tap = UITapGestureRecognizer(target: self, action: #selector(imgBegeniTapped))
        imgBegeni.addGestureRecognizer(tap)
        imgBegeni.isUserInteractionEnabled = true
        
    }
    @objc func imgBegeniTapped (){
      
        Firestore.firestore().document("Fikirler/\(SecilenFikir.DokumanID!)").updateData([Begeni_Sayisi : SecilenFikir.BegeniSayisi+1])
       //Firestore.firestore().document("Fikirler/\(SecilenFikir.DokumanId)").updateData(imgBegeniDegistir())
    }
    
    @IBAction func imgBegeniDegistir(){
        imgBegeni.image = UIImage(named : "begeniacik")
        //imgBegeni.image = UIImage(cgImage: <#T##CGImage#>)
    }
    
    
    func GorunumAyarla(fikir : Fikir, delegate : FikirDelegate?){
        
        
        
        
        print("FikirCell satir 45")
        SecilenFikir = fikir
        lblKullaniciAdi.text = fikir.KullaniciAdi ?? "Misafir"
        
        
        lblTextFikir.text = fikir.FikirText
        lblBegeniSayisi.text = "\(fikir.BegeniSayisi ?? 0)"
        let TarihFormat = DateFormatter()
        TarihFormat.dateFormat = "dd MM YYYY, hh:mm"
        let EklenmeTarihi = TarihFormat.string(from: fikir.EklemeTarihi)
        lblTarih.text = EklenmeTarihi
        lblYorumSayisi.text = "\(fikir.YorumSayisi ?? 0)"
        
        imgSecenekler.isHidden = true
        self.delegate = delegate
        
        if fikir.KullaniciID == Auth.auth().currentUser?.uid{
            imgSecenekler.isHidden = false
            imgSecenekler.isUserInteractionEnabled = true
            let tap = UITapGestureRecognizer(target: self, action: #selector(imgFikirSeceneklerPressed))
            imgSecenekler.addGestureRecognizer(tap)
            
            
        }  
    }
    @objc func imgFikirSeceneklerPressed(){
        delegate?.seceneklerFikirPressed(fikir: SecilenFikir)
    }
}


protocol FikirDelegate {
    func seceneklerFikirPressed(fikir : Fikir)
    
}







