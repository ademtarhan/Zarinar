//
//  PaylasimCell.swift
//  zarinar
//
//  Created by Adem Tarhan on 3.11.2020.
//

import UIKit
import Firebase

class PaylasimCell: UITableViewCell {

    @IBOutlet weak var lblKullaniciAdi: UILabel!
    @IBOutlet weak var lblKategori: UILabel!
    @IBOutlet weak var lblTarih: UILabel!
    @IBOutlet weak var lblFikir: UILabel!
    @IBOutlet weak var lblBegeniSayisi: UILabel!
    @IBOutlet weak var lblYorumSayisi: UILabel!
    @IBOutlet weak var imgBegeni: UIImageView!
    

    var seciliPaylasim : Paylasimlar!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(imgBegeniPressed))
        imgBegeni.addGestureRecognizer(tap)
        imgBegeni.isUserInteractionEnabled = true
        
    }
    
    @objc func imgBegeniPressed(){
        
        Firestore.firestore().document("Fikirler/\(seciliPaylasim.DokumanId!)").updateData([Begeni_Sayisi : seciliPaylasim.BegeniSayisi+1])
    }
    
    

    func GorunumAyari(paylasim : Paylasimlar){
        seciliPaylasim = paylasim
        lblKullaniciAdi.text = paylasim.KullaniciAdi
        lblKategori.text = paylasim.Kategori
        lblFikir.text = paylasim.TextFikir
        let TarihFormat = DateFormatter()
        TarihFormat.dateFormat = "dd MM YYYY, hh:mm"
        let EklenmeTarihi = TarihFormat.string(from: paylasim.EklenmeTarihi)
        lblTarih.text = EklenmeTarihi
        lblBegeniSayisi.text = "\(paylasim.BegeniSayisi ?? 0)"
        lblYorumSayisi.text = "\(paylasim.YorumSayisi ?? 0)"
        
    }

}
