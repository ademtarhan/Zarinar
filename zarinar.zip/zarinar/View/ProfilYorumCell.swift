//
//  ProfilYorumCellTableViewCell.swift
//  zarinar
//
//  Created by Adem Tarhan on 16.11.2020.
//

import UIKit
import Firebase

class ProfilYorumCell: UITableViewCell {
    
    
    @IBOutlet weak var lblYorum: UILabel!
    @IBOutlet weak var lblTarih: UILabel!
    @IBOutlet weak var lblKullaniciAdi: UILabel!
    @IBOutlet weak var imgSecenekler: UIImageView!
    var SeciliYorum : ProfilYorum!
    var Delegate : yorumDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    
    func gorunumAyarla(yorum : ProfilYorum, delegate : yorumDelegate){
        lblKullaniciAdi.text = yorum.KullaniciAdi
        lblYorum.text = yorum.YorumText
        let TarihFormat = DateFormatter()
        TarihFormat.dateFormat = "dd MM YYYY, hh:mm"
        let EklenmeTarihi = TarihFormat.string(from: yorum.EklenmeTarihi)
        lblTarih.text = EklenmeTarihi
        imgSecenekler.isHidden = true
        SeciliYorum = yorum
        self.Delegate = delegate
        if yorum.KullaniciId == Auth.auth().currentUser?.uid{
            imgSecenekler.isHidden = false
            imgSecenekler.isUserInteractionEnabled = true
            let tap = UITapGestureRecognizer(target: self, action: #selector(imgYorumSeceneklerPressed))
            imgSecenekler.addGestureRecognizer(tap)
        }
        
        
                
    }
    @objc func imgYorumSeceneklerPressed(){
        Delegate?.seceneklerYorumPressed(yorum: SeciliYorum)
    }
}


protocol yorumDelegate{
    func seceneklerYorumPressed(yorum : ProfilYorum)
}

