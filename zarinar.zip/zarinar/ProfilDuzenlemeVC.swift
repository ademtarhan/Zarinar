//
//  ProfilDuzenlemeVC.swift
//  zarinar
//
//  Created by Adem Tarhan on 21.10.2020.
//

import Foundation
import UIKit

class ProfilDuzenlemeVC : UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
